CREATE DATABASE celebritydata;
USE celebritydata;

-- data imported --

-- calling out table --
SELECT * FROM celebrity_data;

-- creating Profile table -- 
CREATE TABLE celeb_profile (Name VARCHAR(100) PRIMARY KEY, Age INT, Nationality TEXT); 
INSERT INTO celeb_profile VALUES
('BTS', 11, 'South Korean');
INSERT INTO celeb_profile VALUES
('BLACKPINK', 8, 'South Korean');
INSERT INTO celeb_profile VALUES
('Priyanka Chopra', 42, 'Indian');
INSERT INTO celeb_profile VALUES
('Lupita Nyongo', 41, 'Kenyan');
INSERT INTO celeb_profile VALUES
('Idris Elba', 52, 'British-Ghanaian');
INSERT INTO celeb_profile VALUES
('Jackie Chan', 70, 'Hong Kong Chinese');
INSERT INTO celeb_profile VALUES
('Wizkid', 34, 'Nigerian');
INSERT INTO celeb_profile VALUES
('Burna Boy', 33, 'Nigerian');
INSERT INTO celeb_profile VALUES
('EXO', 12, 'South Korean');
INSERT INTO celeb_profile VALUES
('Trevor Noah', 40, 'South African');
INSERT INTO celeb_profile VALUES
('Shah Rukh Khan', 59, 'Indian');
INSERT INTO celeb_profile VALUES
('Deepika Padukone', 38, 'Indian');
INSERT INTO celeb_profile VALUES
('A.R. Rahman', 57, 'Indian');
INSERT INTO celeb_profile VALUES
('Jay Chou', 45, 'Taiwanese');
INSERT INTO celeb_profile VALUES
('Danai Gurira', 46, 'Zimbabwean-American');
INSERT INTO celeb_profile VALUES
('Chiwetel Ejiofor', 47, 'British-Nigerian');
INSERT INTO celeb_profile VALUES
('Davido', 32, 'Nigerian');
INSERT INTO celeb_profile VALUES
('IU', 31, 'South Korean');
INSERT INTO celeb_profile VALUES
('Fan Bingbing', 43, 'Chinese');
INSERT INTO celeb_profile VALUES
('Song Kang-ho', 57, 'South Korean');
INSERT INTO celeb_profile VALUES
('Genevieve Nnaji', 45, 'Nigerian');
INSERT INTO celeb_profile VALUES
('Rajinikanth', 74, 'Indian');
INSERT INTO celeb_profile VALUES
('Aamir Khan', 59, 'Indian');
INSERT INTO celeb_profile VALUES
('Tiwa Savage', 44, 'Nigerian');
INSERT INTO celeb_profile VALUES
('PSY', 47, 'South Korean');
INSERT INTO celeb_profile VALUES
('Yemi Alade', 35, 'Nigerian');
INSERT INTO celeb_profile VALUES
('Siti Nurhaliza', 45, 'Malaysian');
INSERT INTO celeb_profile VALUES
('Donnie Yen', 61, 'Chinese');
INSERT INTO celeb_profile VALUES
('Zhang Ziyi', 45, 'Chinese');
INSERT INTO celeb_profile VALUES
('Hrithik Roshan', 50, 'Indian');
INSERT INTO celeb_profile VALUES
('Nasty C', 27, 'South African');
INSERT INTO celeb_profile VALUES
('Shatta Wale', 40, 'Ghanaian');
INSERT INTO celeb_profile VALUES
('Stonebwoy', 36, 'Ghanaian');
INSERT INTO celeb_profile VALUES
('Cassper Nyovest', 34, 'South African');
INSERT INTO celeb_profile VALUES
('Sauti Sol', 15, 'Kenyan');
INSERT INTO celeb_profile VALUES
('Ramsey Nouah', 54, 'Nigerian');
INSERT INTO celeb_profile VALUES
('Omotola Jalade', 46, 'Nigerian');
INSERT INTO celeb_profile VALUES
('John Dumelo', 40, 'Ghanaian');
INSERT INTO celeb_profile VALUES
('Adjetey Anang', 54, 'Ghanaian');
INSERT INTO celeb_profile VALUES
('Li Ronghao', 39, 'Chinese');
INSERT INTO celeb_profile VALUES
('G.E.M.', 33, 'Hong Kong Chinese');
INSERT INTO celeb_profile VALUES
('Momo (TWICE)', 28, 'Japanese');
INSERT INTO celeb_profile VALUES
('Namie Amuro', 47, 'Japanese');
INSERT INTO celeb_profile VALUES
('AKB48', 19, 'Japanese');
INSERT INTO celeb_profile VALUES
('Diljit Dosanjh', 40, 'Indian');
INSERT INTO celeb_profile VALUES
('Yo Yo Honey Singh', 41, 'Indian');
INSERT INTO celeb_profile VALUES
('Lee Byung-hun', 54, 'South Korean');
INSERT INTO celeb_profile VALUES
('Takeshi Kitano', 77, 'Japanese');
INSERT INTO celeb_profile VALUES
('Ma Dong-seok', 53, 'South Korean');
INSERT INTO celeb_profile VALUES
('Ayushmann Khurrana', 40, 'Indian');

SELECT * FROM celeb_profile;
SELECT COUNT(*) FROM celeb_profile;


-- creating geography table --
CREATE TABLE celeb_geography (Name VARCHAR(100) PRIMARY KEY, Country TEXT, Region TEXT);
INSERT INTO celeb_geography (Name, Country, Region) VALUES
('BTS', 'South Korea', 'Asia'),
('BLACKPINK', 'South Korea', 'Asia'),
('Priyanka Chopra', 'India', 'Asia'),
('Lupita Nyong\'o', 'Mexico (Kenyan roots)', 'Africa'),
('Idris Elba', 'UK (Ghanaian roots)', 'Africa'),
('Jackie Chan', 'Hong Kong', 'Asia'),
('Wizkid', 'Nigeria', 'Africa'),
('Burna Boy', 'Nigeria', 'Africa'),
('EXO', 'South Korea', 'Asia'),
('Trevor Noah', 'South Africa', 'Africa'),
('Shah Rukh Khan', 'India', 'Asia'),
('Deepika Padukone', 'India', 'Asia'),
('A.R. Rahman', 'India', 'Asia'),
('Jay Chou', 'Taiwan', 'Asia'),
('Danai Gurira', 'USA (Zimbabwean roots)', 'Africa'),
('Chiwetel Ejiofor', 'UK (Nigerian roots)', 'Africa'),
('Davido', 'Nigeria', 'Africa'),
('IU', 'South Korea', 'Asia'),
('Fan Bingbing', 'China', 'Asia'),
('Song Kang-ho', 'South Korea', 'Asia'),
('Genevieve Nnaji', 'Nigeria', 'Africa'),
('Rajinikanth', 'India', 'Asia'),
('Aamir Khan', 'India', 'Asia'),
('Tiwa Savage', 'Nigeria', 'Africa'),
('PSY', 'South Korea', 'Asia'),
('Yemi Alade', 'Nigeria', 'Africa'),
('Siti Nurhaliza', 'Malaysia', 'Asia'),
('Donnie Yen', 'China', 'Asia'),
('Zhang Ziyi', 'China', 'Asia'),
('Hrithik Roshan', 'India', 'Asia'),
('Nasty C', 'South Africa', 'Africa'),
('Shatta Wale', 'Ghana', 'Africa'),
('Stonebwoy', 'Ghana', 'Africa'),
('Cassper Nyovest', 'South Africa', 'Africa'),
('Sauti Sol', 'Kenya', 'Africa'),
('Ramsey Nouah', 'Nigeria', 'Africa'),
('Omotola Jalade', 'Nigeria', 'Africa'),
('John Dumelo', 'Ghana', 'Africa'),
('Adjetey Anang', 'Ghana', 'Africa'),
('Li Ronghao', 'China', 'Asia'),
('G.E.M.', 'Hong Kong', 'Asia'),
('Momo (TWICE)', 'Japan', 'Asia'),
('Namie Amuro', 'Japan', 'Asia'),
('AKB48', 'Japan', 'Asia'),
('Diljit Dosanjh', 'India', 'Asia'),
('Yo Yo Honey Singh', 'India', 'Asia'),
('Lee Byung-hun', 'South Korea', 'Asia'),
('Takeshi Kitano', 'Japan', 'Asia'),
('Ma Dong-seok', 'South Korea', 'Asia'),
('Ayushmann Khurrana', 'India', 'Asia');

SELECT * FROM celeb_geography;
SELECT COUNT(*) FROM celeb_geography;

-- creating celeb_industry table --
CREATE TABLE celeb_industry (Name VARCHAR(100) PRIMARY KEY, Industry TEXT, Genre TEXT);
INSERT INTO celeb_industry (Name, Industry, Genre) VALUES
('BTS', 'Music', 'K-pop'),
('BLACKPINK', 'Music', 'K-pop'),
('Priyanka Chopra', 'Film/Music', 'Bollywood, Hollywood'),
('Lupita Nyong\'o', 'Film', 'Hollywood'),
('Idris Elba', 'Film/Music', 'Hollywood'),
('Jackie Chan', 'Film', 'Action, Comedy'),
('Wizkid', 'Music', 'Afrobeats'),
('Burna Boy', 'Music', 'Afrobeats'),
('EXO', 'Music', 'K-pop'),
('Trevor Noah', 'Comedy', 'Stand-up Comedy'),
('Shah Rukh Khan', 'Film', 'Bollywood'),
('Deepika Padukone', 'Film', 'Bollywood, Hollywood'),
('A.R. Rahman', 'Music', 'Film Music, World Music'),
('Jay Chou', 'Music', 'Mandopop'),
('Danai Gurira', 'Film', 'Hollywood'),
('Chiwetel Ejiofor', 'Film', 'Hollywood'),
('Davido', 'Music', 'Afrobeats'),
('IU', 'Music', 'K-pop'),
('Fan Bingbing', 'Film', 'Chinese Cinema'),
('Song Kang-ho', 'Film', 'Korean Cinema'),
('Genevieve Nnaji', 'Film', 'Nollywood'),
('Rajinikanth', 'Film', 'Tamil Cinema'),
('Aamir Khan', 'Film', 'Bollywood'),
('Tiwa Savage', 'Music', 'Afrobeats'),
('PSY', 'Music', 'K-pop'),
('Yemi Alade', 'Music', 'Afrobeats'),
('Siti Nurhaliza', 'Music', 'Pop, Traditional'),
('Donnie Yen', 'Film', 'Action'),
('Zhang Ziyi', 'Film', 'Chinese Cinema'),
('Hrithik Roshan', 'Film', 'Bollywood'),
('Nasty C', 'Music', 'Hip-hop'),
('Shatta Wale', 'Music', 'Dancehall'),
('Stonebwoy', 'Music', 'Reggae, Dancehall'),
('Cassper Nyovest', 'Music', 'Hip-hop'),
('Sauti Sol', 'Music', 'Afro-pop'),
('Ramsey Nouah', 'Film', 'Nollywood'),
('Omotola Jalade', 'Film', 'Nollywood'),
('John Dumelo', 'Film', 'Nollywood'),
('Adjetey Anang', 'Film', 'Nollywood'),
('Li Ronghao', 'Music', 'Mandopop'),
('G.E.M.', 'Music', 'Cantopop'),
('Momo (TWICE)', 'Music', 'K-pop'),
('Namie Amuro', 'Music', 'J-pop'),
('AKB48', 'Music', 'J-pop'),
('Diljit Dosanjh', 'Music/Film', 'Punjabi, Bollywood'),
('Yo Yo Honey Singh', 'Music', 'Bollywood, Hip-hop'),
('Lee Byung-hun', 'Film', 'Korean Cinema'),
('Takeshi Kitano', 'Film', 'Japanese Cinema'),
('Ma Dong-seok', 'Film', 'Korean Cinema'),
('Ayushmann Khurrana', 'Film', 'Bollywood');

SELECT * FROM celeb_industry;
SELECT COUNT(*) FROM celeb_industry;

-- creating celeb_career table --
CREATE TABLE celeb_career (
    Name VARCHAR(255),
    Net_worth VARCHAR(50),
    Number_of_Awards INT,
    Number_of_Projects INT,
    Profession VARCHAR(255),
    Years_active VARCHAR(50)
);

INSERT INTO celeb_career (Name, Net_worth, Number_of_Awards, Number_of_Projects, Profession, Years_active) 
VALUES 
('BTS', '$3.6 billion', 400, 200, 'Boy Band', '11 years'),
('BLACKPINK', '$1.5 billion', 200, 100, 'Girl Group', '8 years'),
('Priyanka Chopra', '$75 million', 150, 80, 'Actress, Singer', '22 years'),
('Lupita Nyongo', '$20 million', 70, 40, 'Actress', '16 years'), 
('Idris Elba', '$40 million', 70, 150, 'Actor, Musician', '30 years'),
('Jackie Chan', '$400 million', 250, 250, 'Actor, Director', '62 years'),
('Wizkid', '$30 million', 100, 150, 'Singer, Songwriter', '23 years'),
('Burna Boy', '$25 million', 70, 100, 'Singer, Songwriter', '14 years'),
('EXO', '$1 billion', 300, 200, 'Boy Band', '12 years'),
('Trevor Noah', '$100 million', 30, 100, 'Comedian, TV Host', '22 years'),
('Shah Rukh Khan', '$750 million', 300, 150, 'Actor, Producer', '36 years'),
('Deepika Padukone', '$50 million', 150, 70, 'Actress', '18 years'),
('A.R. Rahman', '$300 million', 300, 400, 'Composer, Singer', '32 years'),
('Jay Chou', '$250 million', 200, 150, 'Singer, Songwriter', '24 years'),
('Danai Gurira', '$5 million', 30, 40, 'Actress, Playwright', '20 years'),
('Chiwetel Ejiofor', '$20 million', 70, 100, 'Actor', '29 years'),
('Davido', '$40 million', 70, 100, 'Singer, Songwriter', '13 years'),
('IU', '$50 million', 150, 150, 'Singer, Actress', '16 years'),
('Fan Bingbing', '$100 million', 70, 100, 'Actress', '28 years'),
('Song Kang-ho', '$20 million', 70, 100, 'Actor', '33 years'),
('Genevieve Nnaji', '$15 million', 50, 70, 'Actress, Producer', '26 years'),
('Rajinikanth', '$60 million', 150, 250, 'Actor', '49 years'),
('Aamir Khan', '$250 million', 150, 70, 'Actor, Producer', '36 years'),
('Tiwa Savage', '$15 million', 50, 100, 'Singer, Songwriter', '28 years'),
('PSY', '$80 million', 70, 100, 'Singer, Songwriter', '23 years'),
('Yemi Alade', '$10 million', 30, 100, 'Singer, Songwriter', '14 years'),
('Siti Nurhaliza', '$50 million', 300, 200, 'Singer', '29 years'),
('Donnie Yen', '$50 million', 70, 150, 'Actor, Martial Artist', '40 years'),
('Zhang Ziyi', '$60 million', 70, 70, 'Actress', '28 years'),
('Hrithik Roshan', '$50 million', 150, 70, 'Actor', '44 years'),
('Nasty C', '$10 million', 30, 50, 'Rapper', '11 years'),
('Shatta Wale', '$12 million', 30, 100, 'Singer', '20 years'),
('Stonebwoy', '$10 million', 30, 100, 'Singer', '12 years'),
('Cassper Nyovest', '$10 million', 30, 50, 'Rapper', '11 years'),
('Sauti Sol', '$10 million', 30, 100, 'Band', '19 years'),
('Ramsey Nouah', '$15 million', 30, 150, 'Actor', '34 years'),
('Omotola Jalade', '$15 million', 50, 150, 'Actress', '29 years'),
('John Dumelo', '$8 million', 20, 100, 'Actor', '24 years'),
('Adjetey Anang', '$5 million', 20, 100, 'Actor', '34 years'),
('Li Ronghao', '$20 million', 30, 100, 'Singer, Songwriter', '14 years'),
('G.E.M.', '$30 million', 70, 100, 'Singer, Songwriter', '16 years'),
('Momo (TWICE)', '$15 million', 70, 100, 'Singer, Dancer', '9 years'),
('Namie Amuro', '$100 million', 150, 200, 'Singer', '26 years'),
('AKB48', '$200 million', 200, 600, 'Girl Group', '19 years'),
('Diljit Dosanjh', '$30 million', 70, 150, 'Singer, Actor', '20 years'),
('Yo Yo Honey Singh', '$15 million', 30, 150, 'Singer, Composer', '21 years'),
('Lee Byung-hun', '$30 million', 70, 150, 'Actor', '33 years'),
('Takeshi Kitano', '$50 million', 70, 150, 'Actor, Director', '54 years'),
('Ma Dong-seok', '$15 million', 30, 100, 'Actor', '19 years'),
('Ayushmann Khurrana', '$20 million', 30, 50, 'Actor, Singer', '12 years');

SELECT * FROM celeb_career;
SELECT COUNT(*) FROM celeb_career;

-- Q1 (Top 5 most awarded people in the industry - pie chart) --
SELECT celeb_industry.Name, Number_of_Awards, Industry 
FROM celeb_industry 
JOIN celeb_career 
ON celeb_industry.Name = celeb_career.Name 
ORDER BY Number_of_Awards DESC LIMIT 5;

-- Q2 (Celebs from Africa and their net worth) --
SELECT celeb_career.Name, Country, Net_Worth 
FROM celeb_geography 
JOIN celeb_career 
ON celeb_geography.Name = celeb_career.Name 
WHERE Region = "Africa" 
ORDER BY Net_Worth ASC;

-- Q3 How many celebrities in the music industry have multiple genres? --
SELECT Name, Industry, Genre
FROM celeb_industry
WHERE Industry = 'Music' AND Genre LIKE '%,%';

-- Q4 Top 10 most common genres --
SELECT Genre, COUNT(*) AS `Number_of_Appearances`
FROM celeb_industry
GROUP BY Genre
ORDER BY `Number_of_Appearances` DESC
LIMIT 10;

-- Q5 Average age in film and/or music industry --
SELECT Industry, ROUND(AVG(Age), 0) as Average_Age FROM celeb_industry JOIN celeb_profile ON celeb_industry.Name = celeb_profile.Name WHERE Industry LIKE '%Film%' OR Industry LIKE '%Music%' GROUP BY Industry;

-- Q6 Celebrities with less than 100 projects --
SELECT Name, Number_of_Projects, Number_of_Awards FROM celeb_career WHERE Number_of_Projects < 100 ORDER BY Number_of_Projects ASC LIMIT 10;

-- Q7 Country with highest number of celebrities --
SELECT Country, COUNT(*) Country FROM celeb_geography JOIN celeb_profile ON celeb_profile.Name = celeb_geography.Name GROUP BY Country ORDER BY Country DESC;

-- Q8 Years Active VS Net Worth and Awards --
SELECT 
    Years_Active, 
    Net_Worth, Number_of_Awards, Name
FROM celeb_career
ORDER BY Years_Active ASC;

